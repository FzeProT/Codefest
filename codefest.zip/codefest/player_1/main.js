
const playerId = 'player1-xxx-xxx-xxx';
// key 12f9f808-d843-42df-90a3-2591b88109aa

const CONNECT = "connect";
const DISCONNECT = "disconnect";
const CONNECT_FAILED = "connect_failed";
const ERROR = "error";
const JOIN_GAME = "join game";
const TICKTACK_PLAYER = "ticktack player";
const DRIVE_PLAYER = "drive player";
const apiServer = 'https://codefest.techover.io';
const socket = io.connect(apiServer, { reconnect: true, transports: ['websocket'] });

// move
const MOVE_LEFT = "1"
const MOVE_RIGHT = "2"
const MOVE_UP = "3"
const MOVE_DOWN = "4"
const DROP_BOMB = "b"

// item

const SPACE_STONE = 3;
const MIND_STONE = 4;
const REALITY_STONE = 5;
const POWER_STONE = 6;
const TIME_STONE = 7;
const SOUL_STONE = 8;

// declare variable
let boms = [];
let map = [];
let myID;
let player1 = {}
let player2 = {}

// data in game
let data = {}
let bombExplosed = true
let playerStopMoving = true
let countMoving = 0
let countOfPath = 0
let isPickSpoil = false


// SOCKET EVENTS //

// API-1b

let init = () => {
    connect2Server();
    disconnect();
    connectFailed();
    error();
    joinGame();
    ticktackPlayer();
    drivePlayerResponse();
}

let connect2Server = () => {
    socket.on(CONNECT, () => {
        document.getElementById('connected-status').innerHTML = 'on';
        document.getElementById('socket-status').innerHTML = 'connected';
        console.log('[socket] connected to server');
        socket.emit(JOIN_GAME, {
            game_id: gameId,
            player_id: playerId
        });
    });
}

let disconnect = () => {
    socket.on(DISCONNECT, () => {
        console.warn('[socket] disconnected');
        document.getElementById('socket-status').innerHTML = 'disconnected';
    });
}

let connectFailed = () => {
    socket.on(CONNECT_FAILED, () => {
        console.warn('[socket] connect_failed');
        document.getElementById('socket-status').innerHTML = 'connected failed';
    });
}

let error = () => {
    socket.on(ERROR, (err) => {
        console.error('[socket] error ', err);
        document.getElementById('socket-status').innerHTML = 'error!';
    });
}
//api
let joinGame = () => {
    socket.on(JOIN_GAME, (res) => {
        console.log('[socket] join-game responsed', res);
        document.getElementById('joingame-status').innerHTML = 'on';
    })
}

//api-2
let ticktackPlayer = () => {
    socket.on(TICKTACK_PLAYER, (res) => {
        document.getElementById('ticktack-status').innerHTML = 'on';
        console.log('[socket] ticktack-player responsed, data : ', res);

        if (res.tag == "start-game") {
            data = res
            getBoxNearest();
            bombExplosed = false
            playerStopMoving = false
        }

        if (res.player_id == playerId) {
            data = res

            if (res.tag == 'player:pick-spoil') {
                isPickSpoil = true
            }

            if (res.tag == 'bomb:explosed') {
                bombExplosed = true
            }

            if (res.tag == 'player:stop-moving') {
                ++countMoving
                if (isPickSpoil && !bombExplosed) {
                    playerStopMoving = checkPlayerIn4Corner()
                    bombExplosed = playerStopMoving
                    isPickSpoil = false
                    console.log("playerStopMoving " + playerStopMoving);
                }

                if (countMoving == countOfPath - 1) {
                    playerStopMoving = true
                }
            }

            if (bombExplosed && playerStopMoving) {
                getBoxNearest();
                bombExplosed = false
                playerStopMoving = false
                countMoving = 0
            }
        }
        // "player:pick-spoil"

    })
}
// api-3a
let drivePlayer = (direction) => {
    countOfPath = direction.length
    socket.emit(DRIVE_PLAYER, {
        direction: direction
    })
}


//api-3b
let drivePlayerResponse = () => {
    socket.on(DRIVE_PLAYER, (res) => {
        console.log('[socket] drive-player responsed, data: ', res);
    });
}

const gap = 5;

function getCurrentPosition() {
    let currentX = -1
    let currentY = -1
    let players = data.map_info.players
    for (let i = 0; i < players.length; ++i) {
        if (players[i].id == playerId) {
            currentX = players[i].currentPosition.row;
            currentY = players[i].currentPosition.col;
        }
    }
    return {
        currentX: currentX,
        currentY: currentY
    }
}

function getMapMini(currentX, currentY) {
    let row = data.map_info.size.rows;
    let col = data.map_info.size.cols;

    let mapMini = [0, 0, 0, 0];
    if (currentX - gap < 0) {
        mapMini[0] = 0;
    } else {
        mapMini[0] = currentX - gap;
    }

    if (currentY - gap < 0) {
        mapMini[1] = 0;
    } else {
        mapMini[1] = currentY - gap;
    }

    if (currentX + gap > row) {
        mapMini[2] = row;
    } else {
        mapMini[2] = currentX + gap;
    }

    if (currentY + gap > col) {
        mapMini[3] = col;
    } else {
        mapMini[3] = currentY + gap;
    }

    return mapMini;
}

function checkPlayerIn4Corner() {
    let row = data.map_info.size.rows;
    let col = data.map_info.size.cols;
    let currentPosition = getCurrentPosition();
    let x = currentPosition.currentX;
    let y = currentPosition.currentY;
    console.log("playerStopMoving x" + x);
    console.log("playerStopMoving y" + y);
    return (x == 1 && y == 1) || (x == row - 2 && y == col - 2) ||
        (x == 1 && y == col - 2) || (x == row - 2 && y == 1)
}

function getItem() {
    let items = data.map_info.spoils
    for (let i = 0; i < items.length; ++i) {

    }
    getBoxNearest()
}

function getBoxNearest() {
    let canGo = []
    let currentPosition = getCurrentPosition()
    let mapMini = getMapMini(currentPosition.currentX, currentPosition.currentY);
    let map = data.map_info.map
    let found = false;
    for (let i = mapMini[0]; i < mapMini[2]; ++i) {
        for (let j = mapMini[1]; j < mapMini[3]; ++j) {
            if (map[i][j] == 2) {
                canGo.push({
                    gap: getGap(
                        currentPosition.currentX,
                        currentPosition.currentY,
                        i, j
                    ),
                    x: i,
                    y: j
                })
            }
        }
    }
    canGo.sort(compare);
    let map2D = getMapIn2D()
    for (let k = 0; k < canGo.length; ++k) {
        map2D[canGo[k].x][canGo[k].y] = 1
        found = getBackPath(canGo[k], map2D, map)
        map2D[canGo[k].x][canGo[k].y] = 0;
        if (found) {
            break;
        }
    }
}

function getPath(map2D, start, end) {
    let graph = new Graph(map2D);
    let path = astar.search(
        graph,
        graph[start.x][start.y],
        graph[end.x][end.y]
    );

    return path;
}
const gameId = '09952e66-a7c3-45f3-90f4-5dd88cc6b838';

function getPathToGetItem(){
    let items = data.map_info.spoils;
        if (items.length > 0) {
            map2D[directionCanGo.x][directionCanGo.y] = 0
            for (let i = 0; i < items.length; ++i) {
                if (items[i].spoil_type != TIME_STONE) {
                    let graphToItem = new Graph(map2D);
                    let pathToItem = astar.search(
                        graphToItem,
                        graphToItem.grid[currentPosition.currentX][currentPosition.currentY],
                        graphToItem.grid[items[i].row][items[i].col]);

                    if (pathToItem.length > 0 && pathToItem.length < 8 && items[i].row != currentPosition.currentX && items[i].col != currentPosition.currentY) {
                        direction = getDirection(path, pathToItem, getCurrentPosition());
                        if (pathToItem.length > 0) {
                            drivePlayer(direction);
                            found = true;
                            break;
                        }
                    }
                }
            }
            map2D[directionCanGo.x][directionCanGo.y] = 1
        }
}

function getBackPath(directionCanGo, map2D, map) {
    let directionCanBack = []
    let graph = new Graph(map2D);
    let currentPosition = getCurrentPosition();
    let found = false;

    let path = getPath(
        map2D,
        {
            x: getCurrentPosition.currentX,
            y: currentPosition.currentY
        },
        {
            x: directionCanGo.x,
            y: directionCanGo.y
        }
    )
    if (path.length >= 1) {
        if (path.length > 1) {
            currentPosition.currentX = path[path.length - 2].x;
            currentPosition.currentY = path[path.length - 2].y;
        }

        let items = data.map_info.spoils;
        if (items.length > 0) {
            map2D[directionCanGo.x][directionCanGo.y] = 0
            for (let i = 0; i < items.length; ++i) {
                if (items[i].spoil_type != TIME_STONE) {
                    console.log("spoil_type " + items[i].spoil_type)
                    let graphToItem = new Graph(map2D);
                    let pathToItem = astar.search(
                        graphToItem,
                        graphToItem.grid[currentPosition.currentX][currentPosition.currentY],
                        graphToItem.grid[items[i].row][items[i].col]);

                    if (pathToItem.length > 0 && pathToItem.length < 8 && items[i].row != currentPosition.currentX && items[i].col != currentPosition.currentY) {
                        direction = getDirection(path, pathToItem, getCurrentPosition());
                        if (pathToItem.length > 0) {
                            drivePlayer(direction);
                            found = true;
                            break;
                        }
                    }
                }
            }
            map2D[directionCanGo.x][directionCanGo.y] = 1
        }
        if (!found) {
            mapMini = getMapMini(currentPosition.currentX, currentPosition.currentY);
            for (let i = mapMini[0]; i < mapMini[2]; ++i) {
                for (let j = mapMini[1]; j < mapMini[3]; ++j) {
                    if (map[i][j] == 0 && i != currentPosition.currentX && j != currentPosition.currentY) {
                        directionCanBack.push({
                            gap: getGap(
                                currentPosition.currentX,
                                currentPosition.currentY,
                                i, j
                            ),
                            x: i,
                            y: j
                        })
                    }
                }
            }
            directionCanBack.sort(compare);
            map2D[directionCanGo.x][directionCanGo.y] = 0;
            graph = new Graph(map2D);
            for (let r = 0; r < directionCanBack.length; r++) {
                let direction = ""
                let pathBack = astar.search(
                    graph,
                    graph.grid[currentPosition.currentX][currentPosition.currentY],
                    graph.grid[directionCanBack[r].x][directionCanBack[r].y]);

                if (pathBack.length > 0 && pathBack.length <= directionCanBack[r].gap * 2) {
                    console.log("pathBack: " + pathBack)
                    direction = getDirection(path, pathBack, getCurrentPosition());
                    console.log("direction: " + direction);
                    if (pathBack.length > 0) {
                        drivePlayer(direction);
                        found = true;
                        break;
                    }
                }
            }
            map2D[currentPosition.currentX][currentPosition.currentY] = 1;
        }
    }

    return found

}

function getDirection(move, moveBack, currentPosition) {
    let direction = ""
    let x = currentPosition.currentX;
    let y = currentPosition.currentY;
    for (let i = 0; i < move.length - 1; ++i) {
        if (move[i].x > x) {
            direction += MOVE_DOWN
        }

        if (move[i].x < x) {
            direction += MOVE_UP
        }

        if (move[i].y > y) {
            direction += MOVE_RIGHT
        }

        if (move[i].y < y) {
            direction += MOVE_LEFT
        }

        x = move[i].x;
        y = move[i].y;
    }

    direction += DROP_BOMB

    for (let i = 0; i < moveBack.length; ++i) {
        if (moveBack[i].x > x) {
            direction += MOVE_DOWN
        }

        if (moveBack[i].x < x) {
            direction += MOVE_UP
        }

        if (moveBack[i].y > y) {
            direction += MOVE_RIGHT
        }

        if (moveBack[i].y < y) {
            direction += MOVE_LEFT
        }

        x = moveBack[i].x;
        y = moveBack[i].y;
    }

    return direction;


}

function getGap(x1, y1, x2, y2) {
    return Math.abs(x1 - x2) + Math.abs(y1 - y2);
}

function getMapIn2D() {
    let row = data.map_info.size.rows;
    let col = data.map_info.size.cols;
    let newMap = new Array(row);
    let map = data.map_info.map;
    for (let i = 0; i < row; ++i) {
        let arrayRow = new Array(col);
        for (let j = 0; j < col; ++j) {
            if (map[i][j] == 0) {
                arrayRow[j] = 1;
            } else {
                arrayRow[j] = 0;
            }
        }
        newMap[i] = arrayRow;
    }
    return newMap;
}

function compare(a, b) {
    return a.gap - b.gap;
}

init();
